﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class CarsInCompany : Form
    {
        public CarsInCompany()
        {
            InitializeComponent();
        }
        private SqlConnection sqlConnection = null;

        private void CarsInCompany_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
            LoadData();
        }
        private void LoadData()
        {
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT  Cars.car_id, name_mark AS 'Марка', " +
                    "number_car AS 'Номер машины', " +
                    "god_vipuska AS 'Год выпуска', " +
                    "probeg AS 'Пробег', specific AS 'Спецификация' FROM Cars " +
                    "JOIN Marks ON Marks.mark_id = Cars.mark_id;" , sqlConnection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuPolz formmenu = new formmenuPolz();
            formmenu.Show();
        }
    }
}
