﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class TarifsAndUslugi : Form
    {
        public TarifsAndUslugi()
        {
            InitializeComponent();
        }
        private SqlConnection sqlConnection = null;
        private void LoadData()
        {
            
        }

        private void TarifsAndUslugi_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
            label1.Visible = false;
            dataGridView1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuPolz formmenu = new formmenuPolz();
            formmenu.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    label1.Text = "Тарифы";
                    label1.Visible = true;
                    dataGridView1.Visible = true;
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT  tarif_id AS 'Номер тарифа', " +
                            "[name_tarif] AS 'Название тарифа', " +
                            "opisanie AS 'Описание тарифа', " +
                            "price AS 'Цена за километр поездки' FROM Tarifs;", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        dataGridView1.DataSource = table;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
                case 1:
                    label1.Text = "Услуги";
                    label1.Visible = true;
                    dataGridView1.Visible = true;
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT  uslug_id AS 'Номер услуги', " +
                            "name_uslug AS 'Название услуги', " +
                            "opisanie AS 'Описание услуги', " +
                            "price AS 'Цена за услугу' FROM Uslugi;", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        dataGridView1.DataSource = table;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
            }
        }
    }
}
