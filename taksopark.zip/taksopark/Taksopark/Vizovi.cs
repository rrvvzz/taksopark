﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class Vizovi : Form
    {
        private SqlConnection sqlConnection = null;
        public Vizovi()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT vizov_id AS 'Номер вызова', date_viz AS 'Дата_вызова', " +
                    "time_viz AS 'Время_вызова', number_phone AS 'Номер телефона', " +
                    "from_adress AS 'Откуда', where_adress AS 'Куда', " +
                    "Vizovi.car_id, number_car AS 'Номер машины', sotrudnik_id AS 'Номер сотрудника', " +
                    "name_tarif AS 'Название тарифа', Tarifs.opisanie AS 'Описание тарифа', " +
                    "name_uslug AS 'Название услуги', Uslugi.opisanie AS 'Описание услуги' FROM Vizovi " +
                    "JOIN Tarifs ON Vizovi.tarif_id = Tarifs.tarif_id " +
                    "JOIN Uslugi ON Vizovi.uslug_id = Uslugi.uslug_id JOIN Cars ON Vizovi.car_id = Cars.car_id; ", sqlConnection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuDir formmenu = new formmenuDir();
            formmenu.Show();
        }
        private void Vizovi_Load_1(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
            LoadData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "";
                    break;
                case 1:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Дата_вызова LIKE '01.01.2020'";
                    break;
                case 2:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Дата_вызова LIKE '02.01.2020'";
                    break;
                case 3:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Дата_вызова LIKE '03.01.2020'";
                    break;
            }
        }
    }
}

