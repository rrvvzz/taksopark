﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class Otdelkadrov : Form
    {
        private SqlConnection sqlConnection = null;

        private SqlDataAdapter adapter1 = null;

        public Otdelkadrov()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
            LoadData1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuDir formmenuDir = new formmenuDir();
            formmenuDir.Show();
        }

        private void LoadData1()
        {
            try
            {
                adapter1 = new SqlDataAdapter("SELECT sotrudnik_id AS 'Номер сотрудника', [name] AS 'Имя', " +
                    "age AS 'Возраст', sex AS 'Пол', adress AS 'Адресс', " +
                    "phone AS 'Номер телефона', passport AS 'Паспортные данные', " +
                    "Dolzhnosti.dolzhnost_id AS 'Номер должности', [name_dolzhnost] AS 'Название должности', " +
                    "oklad AS 'Оклад', obyazannost AS 'Обязанность', trebovanie AS 'Требование' FROM Sotrudniki " +
                    "JOIN Dolzhnosti ON Sotrudniki.dolzhnost_id = Dolzhnosti.dolzhnost_id; ", sqlConnection);
                DataTable table = new DataTable();
                adapter1.Fill(table);
                dataGridView2.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            (dataGridView2.DataSource as DataTable).DefaultView.RowFilter = $"Имя LIKE '%{textBox1.Text}%'";
        }
    }
}

