﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class Sotrudniki : Form
    {
        private SqlConnection sqlConnection = null;

        private SqlCommandBuilder sqlBuilder = null;

        private SqlDataAdapter adapter = null;

        private DataSet dataSet = null;

        private bool newRowAdding = false;
        public Sotrudniki()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            try
            {
                adapter = new SqlDataAdapter("SELECT * ,'Delete' AS [Delete] FROM Sotrudniki", sqlConnection);

                sqlBuilder = new SqlCommandBuilder(adapter);

                sqlBuilder.GetInsertCommand();
                sqlBuilder.GetUpdateCommand();
                sqlBuilder.GetDeleteCommand();

                dataSet = new DataSet();

                adapter.Fill(dataSet, "Sotrudniki");

                dataGridView1.DataSource = dataSet.Tables["Sotrudniki"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[8, i] = linkCell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
        private void ReloadData()
        {
            try
            {
                dataSet.Tables["Sotrudniki"].Clear();

                adapter.Fill(dataSet, "Sotrudniki");

                dataGridView1.DataSource = dataSet.Tables["Sotrudniki"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[8, i] = linkCell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void Sotrudniki_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuDir formmenu = new formmenuDir();
            formmenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 8)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

                    if (task == "Delete")
                    {
                        if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo)
                            == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);
                            dataSet.Tables["Sotrudniki"].Rows[rowIndex].Delete();
                            adapter.Update(dataSet, "Sotrudniki");
                        }
                    }
                    else if (task == "Insert")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;

                        DataRow row = dataSet.Tables["Sotrudniki"].NewRow();

                        row["sotrudnik_id"] = dataGridView1.Rows[rowIndex].Cells["sotrudnik_id"].Value;
                        row["name"] = dataGridView1.Rows[rowIndex].Cells["name"].Value;
                        row["age"] = dataGridView1.Rows[rowIndex].Cells["age"].Value;
                        row["sex"] = dataGridView1.Rows[rowIndex].Cells["sex"].Value;
                        row["adress"] = dataGridView1.Rows[rowIndex].Cells["adress"].Value;
                        row["phone"] = dataGridView1.Rows[rowIndex].Cells["phone"].Value;
                        row["passport"] = dataGridView1.Rows[rowIndex].Cells["passport"].Value;
                        row["dolzhnost_id"] = dataGridView1.Rows[rowIndex].Cells["dolzhnost_id"].Value;

                        dataSet.Tables["Sotrudniki"].Rows.Add(row);
                        dataSet.Tables["Sotrudniki"].Rows.RemoveAt(dataSet.Tables["Sotrudniki"].Rows.Count - 1);
                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                        dataGridView1.Rows[e.RowIndex].Cells[8].Value = "Delete";

                        adapter.Update(dataSet, "Sotrudniki");

                        newRowAdding = false;
                    }
                    else if (task == "Update")
                    {
                        int r = e.RowIndex;

                        dataSet.Tables["Sotrudniki"].Rows[r]["sotrudnik_id"] = dataGridView1.Rows[r].Cells["sotrudnik_id"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["name"] = dataGridView1.Rows[r].Cells["name"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["age"] = dataGridView1.Rows[r].Cells["age"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["sex"] = dataGridView1.Rows[r].Cells["sex"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["adress"] = dataGridView1.Rows[r].Cells["adress"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["phone"] = dataGridView1.Rows[r].Cells["phone"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["passport"] = dataGridView1.Rows[r].Cells["passport"].Value;
                        dataSet.Tables["Sotrudniki"].Rows[r]["dolzhnost_id"] = dataGridView1.Rows[r].Cells["dolzhnost_id"].Value;

                        adapter.Update(dataSet, "Sotrudniki");
                        dataGridView1.Rows[e.RowIndex].Cells[8].Value = "Delete";
                    }
                    ReloadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                if (newRowAdding == false)
                {
                    newRowAdding = true;

                    int lastRaw = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRaw];
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[8, lastRaw] = linkCell;
                    row.Cells["Delete"].Value = "Insert";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if ((newRowAdding == false))
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingRow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[8, rowIndex] = linkCell;
                    editingRow.Cells["Delete"].Value = "Update";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
    }
}
