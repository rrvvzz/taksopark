﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class VizovInfo : Form
    {
        public VizovInfo()
        {
            InitializeComponent();
            button2.Enabled = false;
            dataGridView1.Visible = false;
        }
        private SqlConnection sqlConnection = null;

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuPolz formmenu = new formmenuPolz();
            formmenu.Show();
        }

        private void VizovInfo_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            LoadData();
        }
        private void LoadData()
        {
            string number;
            number = Convert.ToString(textBox1.Text);
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT vizov_id AS 'Номер_вызова', date_viz AS 'Дата_вызова', " +
                    "time_viz AS 'Время_вызова', number_phone AS 'Номер телефона', " +
                    "from_adress AS 'Откуда', where_adress AS 'Куда', " +
                    "Vizovi.car_id, number_car AS 'Номер машины', sotrudnik_id AS 'Номер сотрудника', " +
                    "name_tarif AS 'Название тарифа', Tarifs.opisanie AS 'Описание тарифа', " +
                    "name_uslug AS 'Название услуги', Uslugi.opisanie AS 'Описание услуги' FROM Vizovi " +
                    "JOIN Tarifs ON Vizovi.tarif_id = Tarifs.tarif_id " +
                    "JOIN Uslugi ON Vizovi.uslug_id = Uslugi.uslug_id JOIN Cars ON Vizovi.car_id = Cars.car_id; ", sqlConnection);

                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;

                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Номер_вызова = {number}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
    }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                button2.Enabled = false;
            }
            else
            {
                button2.Enabled = true;
            }
        }
    }
}
