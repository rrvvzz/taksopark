﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class PassForm : Form
    {
        public PassForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "qwerty")
            {
                this.Hide();
                formmenuDir formmenuDir = new formmenuDir();
                formmenuDir.Show();
            }
            else
            {
                MessageBox.Show("Вы ввели неверный пароль!","Ошибка!");
                this.Hide();
                Autoriz autoriz = new Autoriz();
                autoriz.Show();
            }
        }
    }
}
