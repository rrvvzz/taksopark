﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Taksopark
{
    public partial class Autopark : Form
    {
        public Autopark()
        {
            InitializeComponent();
        }
        private SqlConnection sqlConnection = null;

        private void LoadData()
        {
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT  Cars.car_id, Marks.mark_id, name_mark AS 'Марка', " +
                    "number_car AS 'Номер машины', number_cuzov  AS 'Номер кузова', " +
                    "number_dvig AS 'Номер двигателя', god_vipuska AS 'Год выпуска', " +
                    "probeg AS 'Пробег', price  AS 'Цена', specific AS 'Спецификация', " +
                    "Sotrudniki.sotrudnik_id  AS 'Номер сотрудника', dolzhnost_id AS 'Номер должности', " +
                    "[name] AS 'Имя сотрудника' FROM Cars " +
                    "JOIN Marks ON Marks.mark_id = Cars.mark_id " +
                    "JOIN Sotrudniki ON Sotrudniki.sotrudnik_id = Cars.sotrudnik_id; ", sqlConnection);
                
                DataTable table = new DataTable();
                adapter.Fill(table);
                
                dataGridView1.DataSource = table;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            formmenuDir formmenuDir = new formmenuDir();
            formmenuDir.Show();
        }

        private void Autopark_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=TAKSOPARK;Integrated Security=True");
            sqlConnection.Open();
            LoadData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "";
                    break;
                case 1:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Марка LIKE 'Ford'";
                    break;
                case 2:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Марка LIKE 'Mitsubishi'";
                    break;
                case 3:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Марка LIKE 'Mercedes-Benz'";
                    break;
                case 4:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Марка LIKE 'Toyota'";
                    break;
                case 5:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"Марка LIKE 'Mercedes-Maybach'";
                    break;
            }
        }
    }
}
